# WhaTicket Saas 4E</br>
Funcionando com Baileys 6.4.0 - Julho de 2023 </br>
</br> Atualizado referencias para a bilioteca @WhiskeySockets/Baileys</br>
Modificado AnyWASocket, WALegacySocket, LegacyAuthenticationCreds</br>
</br>

